﻿using System.ServiceModel;

namespace IServices
{
    [ServiceContract]
    interface IServiceKuchyna
    {
    }
}
