﻿using DatabaseEntities;


namespace IDatabaseExecutor
{

    public interface IDBDatabaseExecutor
    {
        risTabulky risContext { get; }
    }
}
