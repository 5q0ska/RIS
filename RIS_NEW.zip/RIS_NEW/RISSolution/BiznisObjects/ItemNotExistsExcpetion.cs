﻿using System;

namespace BiznisObjects
{
    class ItemNotExistsExcpetion : Exception
    {
    }
}
