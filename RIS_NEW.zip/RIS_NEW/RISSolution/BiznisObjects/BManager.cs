﻿namespace BiznisObjects
{
    public class BManager
    {
       /* private IRestaurantStolService aComm;
        private readonly List<BJedlo> aJedloList = null;

        public List<BJedlo> jedloList
        {
            get
            {
                if (aJedloList == null)
                {
                  //  IList list = aComm.jedloList;

                    //napln aJedloList z list
                }
                return aJedloList;
            }
        }*/
    }
}
