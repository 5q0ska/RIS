﻿using System;
namespace TransferObjects
{
    public class TTableReservations
    {
        public TTableReservations()
        {
        }
    }
}
