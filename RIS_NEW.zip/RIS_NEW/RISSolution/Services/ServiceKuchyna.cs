﻿namespace Services
{
    class ServiceKuchyna
    {
    }
}
